package Formularios;

import Clases.ComprobarConexionInternet;
import Clases.EnviarMail;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class CrearMensaje extends javax.swing.JFrame {

    public String adjunto;
    private boolean conexion;
    String correo;
    String contraseña;
    String nombre;
    String archivo;
    
    public CrearMensaje(String correo, String contra) {
        this.correo = correo;
        this.contraseña = contra;
        initComponents();        
    }
    
    private CrearMensaje(){
        
    }
    
    public void verificarConexion()
    {
        ComprobarConexionInternet google = new ComprobarConexionInternet();
        conexion = google.test();
        System.out.println(conexion);
        
        if(conexion)
        {
            System.out.println("Esta conectado a internet");
        }
        else
        {
            System.out.println("No hay conexion");
            jLab_EstadoInternet.setText("Sin conexión a internet");
            jTextDestino.setEnabled(conexion);
            jTextAsunto.setEnabled(false);
            jTextAreaULTEMAIL.setEnabled(false);
            jButEnviarEmail.setEnabled(false);
            jButLimpiarCampos.setEnabled(false);
            jButAdjuntarArchivos.setEnabled(false);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextDestino = new javax.swing.JTextField();
        jTextAsunto = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaULTEMAIL = new javax.swing.JTextArea();
        jButEnviarEmail = new javax.swing.JButton();
        jButLimpiarCampos = new javax.swing.JButton();
        jButAdjuntarArchivos = new javax.swing.JButton();
        jButSalir = new javax.swing.JButton();
        jButChecarInter = new javax.swing.JButton();
        jLab_EstadoInternet = new javax.swing.JLabel();
        jTextRutaAdjunto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabEstado = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextAreaMSG1 = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Formularios/Banner.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Para:");

        jTextDestino.setText("alu.18131226@correo.itlalaguna.edu.mx");
        jTextDestino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextDestinoActionPerformed(evt);
            }
        });

        jTextAsunto.setText("Mensaje de prueba 21/09/22");
        jTextAsunto.setToolTipText("");

        jTextAreaULTEMAIL.setColumns(20);
        jTextAreaULTEMAIL.setRows(5);
        jTextAreaULTEMAIL.setText("\n");
        jScrollPane1.setViewportView(jTextAreaULTEMAIL);

        jButEnviarEmail.setBackground(new java.awt.Color(0, 204, 204));
        jButEnviarEmail.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButEnviarEmail.setForeground(new java.awt.Color(255, 255, 255));
        jButEnviarEmail.setText("Enviar Email");
        jButEnviarEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButEnviarEmailActionPerformed(evt);
            }
        });

        jButLimpiarCampos.setBackground(new java.awt.Color(0, 204, 204));
        jButLimpiarCampos.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButLimpiarCampos.setForeground(new java.awt.Color(255, 255, 255));
        jButLimpiarCampos.setText("Limpiar Campos");
        jButLimpiarCampos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButLimpiarCamposActionPerformed(evt);
            }
        });

        jButAdjuntarArchivos.setBackground(new java.awt.Color(0, 204, 204));
        jButAdjuntarArchivos.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButAdjuntarArchivos.setForeground(new java.awt.Color(255, 255, 255));
        jButAdjuntarArchivos.setText("Adjuntar archivo");
        jButAdjuntarArchivos.setToolTipText("Adjuntar");
        jButAdjuntarArchivos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButAdjuntarArchivosActionPerformed(evt);
            }
        });

        jButSalir.setBackground(new java.awt.Color(0, 204, 204));
        jButSalir.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButSalir.setForeground(new java.awt.Color(255, 255, 255));
        jButSalir.setText("Salir");
        jButSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButSalirActionPerformed(evt);
            }
        });

        jButChecarInter.setBackground(new java.awt.Color(0, 204, 204));
        jButChecarInter.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButChecarInter.setForeground(new java.awt.Color(255, 255, 255));
        jButChecarInter.setText("Checar Internet");
        jButChecarInter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButChecarInterActionPerformed(evt);
            }
        });

        jLab_EstadoInternet.setFont(new java.awt.Font("DejaVu Serif", 1, 14)); // NOI18N
        jLab_EstadoInternet.setForeground(new java.awt.Color(255, 255, 255));

        jTextRutaAdjunto.setEditable(false);
        jTextRutaAdjunto.setText("C:\\Users\\Kazta\\Desktop\\rombosman.png");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Asunto:");

        jLabEstado.setForeground(new java.awt.Color(255, 255, 255));
        jLabEstado.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        jLabel5.setFont(new java.awt.Font("Century Gothic", 3, 18)); // NOI18N
        jLabel5.setText("Cualquier problema favor de reportarlo al correo:");

        jLabel6.setFont(new java.awt.Font("Century Gothic", 3, 18)); // NOI18N
        jLabel6.setText("alu.18131226@correo.itlalaguna.edu.mx.");

        jLabel7.setFont(new java.awt.Font("Century Gothic", 3, 18)); // NOI18N
        jLabel7.setText("Adjuntar captura y breve descripción de lo sucedido.");

        jTextAreaMSG1.setColumns(20);
        jTextAreaMSG1.setRows(5);
        jTextAreaMSG1.setText("Prueba realizada con éxito");
        jScrollPane2.setViewportView(jTextAreaMSG1);

        jLabel4.setText("Último correo al cuál enviaste mensaje:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButEnviarEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButLimpiarCampos)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButAdjuntarArchivos)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextRutaAdjunto, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(787, 787, 787)
                                .addComponent(jButSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButChecarInter)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextAsunto)
                            .addComponent(jTextDestino, javax.swing.GroupLayout.PREFERRED_SIZE, 975, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(196, 196, 196)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLab_EstadoInternet, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1049, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1049, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLab_EstadoInternet, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)))
                    .addComponent(jButChecarInter, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextDestino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextAsunto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 117, Short.MAX_VALUE)
                        .addComponent(jLabEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButEnviarEmail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButAdjuntarArchivos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButLimpiarCampos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextRutaAdjunto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1265, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextDestinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextDestinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextDestinoActionPerformed

    private void jButAdjuntarArchivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButAdjuntarArchivosActionPerformed
        JFileChooser fc = new JFileChooser();
        int option = fc.showOpenDialog(this);
        if(option == JFileChooser.APPROVE_OPTION){
            archivo = fc.getSelectedFile().getPath();
            nombre = fc.getSelectedFile().getName();
            jTextRutaAdjunto.setText(archivo);
        }
    }//GEN-LAST:event_jButAdjuntarArchivosActionPerformed

    private void jButSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButSalirActionPerformed
        this.dispose();
        Login ventana = new Login();     
        ventana.setVisible(true);
    }//GEN-LAST:event_jButSalirActionPerformed

    private void jButEnviarEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButEnviarEmailActionPerformed
        jButChecarInter.doClick();
             
        if(conexion == true){
            if(jTextDestino.getText().equals("")){
                JOptionPane.showMessageDialog(null, "No ha agregado el destinatario");
            }
            else{
                int valor = 5;
                if(jTextAsunto.getText().equals("")){
                    valor = JOptionPane.showConfirmDialog(rootPane, "¿Esta seguro que desea enviar el correo sin asunto?");
                }
                if(valor == 5 || valor == 0){
                    EnviarMail obj = new EnviarMail(correo, contraseña, jTextDestino, jTextAsunto, jTextRutaAdjunto, jTextAreaULTEMAIL, nombre, jLabEstado);
                    obj.start();
                    obj = null;
                }
            } 
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Intenta: \n      -Comprobar los cables de red, el módem y el router \n      -Volver a conectarte a Wi-Fi" , "Sin internet", JOptionPane.PLAIN_MESSAGE);
            
        }
        jTextAreaULTEMAIL.setText(jTextDestino.getText());
    }//GEN-LAST:event_jButEnviarEmailActionPerformed

    private void jButChecarInterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButChecarInterActionPerformed
        verificarConexion();
    }//GEN-LAST:event_jButChecarInterActionPerformed

    private void jButLimpiarCamposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButLimpiarCamposActionPerformed
        jTextDestino.setText("");
        jTextAsunto.setText("");
        jTextAreaULTEMAIL.setText("");
        jTextRutaAdjunto.setText("");
    }//GEN-LAST:event_jButLimpiarCamposActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CrearMensaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CrearMensaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CrearMensaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CrearMensaje.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrearMensaje().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButAdjuntarArchivos;
    private javax.swing.JButton jButChecarInter;
    private javax.swing.JButton jButEnviarEmail;
    private javax.swing.JButton jButLimpiarCampos;
    private javax.swing.JButton jButSalir;
    private javax.swing.JLabel jLabEstado;
    private javax.swing.JLabel jLab_EstadoInternet;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private static javax.swing.JTextArea jTextAreaMSG1;
    private javax.swing.JTextArea jTextAreaULTEMAIL;
    private static javax.swing.JTextField jTextAsunto;
    private static javax.swing.JTextField jTextDestino;
    private javax.swing.JTextField jTextRutaAdjunto;
    // End of variables declaration//GEN-END:variables
}
